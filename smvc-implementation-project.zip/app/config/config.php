<?php
// DB Params
define('DB_HOST', 'localhost'); 
define('DB_USER', 'root'); 
define('DB_PASS', '847847'); 
define('DB_NAME', 'shareposts');        

// App Root 
define('APPROOT' ,dirname(dirname(__FILE__)));  

// URL Root 
define('URLROOT', 'http://shareposts.com');     

// Site Name
define('SITENAME', 'SharePosts'); 

// Default time zone
date_default_timezone_set("Asia/Dhaka"); 

//default charset 
//header('Content-Type: text/html; charset=utf-8');
//
//version 
define('APPVERSION', '1.0.0');